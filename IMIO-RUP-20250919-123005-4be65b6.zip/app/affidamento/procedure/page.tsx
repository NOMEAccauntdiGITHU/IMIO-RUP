// app/affidamento/procedure/[id]/page.tsx
type Props = { params: { id: string } };

export default function Page({ params }: Props) {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Affidamento – Dettaglio Procedura</h1>
      <div className="card p-6">ID: <code>{params.id}</code></div>
    </div>
  );
}
