export default function Page({params}:{params:{id:string}}){return(<div><h1>Affidamento – Dettaglio</h1><div>ID: <code>{params.id}</code></div></div>);}
