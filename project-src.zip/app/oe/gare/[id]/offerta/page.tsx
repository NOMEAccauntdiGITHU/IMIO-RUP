export default function Page() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Portale OE – Invio Offerta</h1>
      <div className="card p-6">Sezione pronta per integrazione dati Supabase e azioni.</div>
    </div>
  );
}
