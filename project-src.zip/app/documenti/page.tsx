export default function Page() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Archivio Documenti</h1>
      <div className="card p-6">Sezione pronta per integrazione dati Supabase e azioni.</div>
    </div>
  );
}
